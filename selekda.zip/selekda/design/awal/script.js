let banner = document.querySelector(".card-nbanner.start");
let nbanner = document.querySelectorAll(".card-nbanner");
let timerBanner = document.querySelector(".timer-banner");
let bannerNext = document.querySelector(".next-banner");
let currentBanner = document.querySelector(".current-banner img");

currentBanner.src = nbanner[0].querySelector("img").src;

let a = 0;
let b = 0;
let time = 5000;
setInterval(() => {
    a++;

    if (a > bannerNext.children.length - 1) {
        a = 0;
    }

    currentBanner.src = nbanner[a].querySelector("img").src;

    banner.style.marginTop = -(95 * a) + "%";
}, time);

setInterval(() => {
    b += time / 3500;

    timerBanner.style.width = b + "px";
}, 1);

banner.addEventListener("transitionend", () => {
    b = 0;
});
