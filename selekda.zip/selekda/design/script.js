// function banner() {
// let otwBanner = document.querySelector(".card-nbanner.otw");
// let startBanner = document.querySelector(".card-nbanner.start");
// let posaBanner = document.querySelector(".posa-nbanner");
//     setTimeout(() => {
// otwBanner.style.left = "-50%";
// otwBanner.style.bottom = "0";
// otwBanner.style.aspectRatio = "1/0.92";
// otwBanner.style.width = "110vh";
// posaBanner.style.paddingLeft = "0";
//     }, 2000);
//     otwBanner.addEventListener("transitionend", () => {
//         posaBanner.appendChild(posaBanner.firstChild);
//         startBanner.classList.remove("start");
//         otwBanner.classList.add("start");
//         otwBanner.classList.remove("otw");
//         setTimeout(() => {
//             posaBanner.children[1].classList.add("otw");
//             banner();
//         }, 100);
//     });
// }

// banner();

let indexBn = 0;

let posaBanner = document.querySelector(".posa-nbanner");
let cardnBanner = document.querySelectorAll(".card-nbanner");
cardnBanner[1].classList.add("otw");

setInterval(() => {
    cardnBanner = document.querySelectorAll(".card-nbanner");
    cardnBanner[1].classList.add("otw");
    posaBanner.style = "transition: 0;";
    posaBanner.style.paddingLeft = "320px";

    setTimeout(() => {
        posaBanner.style = "transition: 1s;";
        cardnBanner[1].style.left = "-50%";
        setTimeout(() => {
            cardnBanner[1].style.bottom = "0";
            cardnBanner[1].style.aspectRatio = "1/0.78";
            cardnBanner[1].style.width = "130vh";
            posaBanner.style.paddingLeft = "0";

            cardnBanner[1].addEventListener("transitionend", () => {
                posaBanner.appendChild(cardnBanner[0]);
                posaBanner.lastElementChild.classList.remove("start");
                posaBanner.lastElementChild.style = "";
                posaBanner.firstElementChild.classList.replace("otw", "start");
            });
        }, 100);
    }, 100);
}, 5000);
