// banner
let posaBanner = document.querySelector(".posa-nbanner");
let cardnBanner = document.querySelectorAll(".card-nbanner");
cardnBanner[1].classList.add("otw");

setInterval(() => {
    cardnBanner = document.querySelectorAll(".card-nbanner");
    cardnBanner[1].classList.add("otw");
    posaBanner.style = "transition: 0;";
    posaBanner.style.paddingLeft = "320px";

    setTimeout(() => {
        posaBanner.style = "transition: 1s;";
        cardnBanner[1].style.left = "-50%";
        setTimeout(() => {
            cardnBanner[1].style.bottom = "0";
            cardnBanner[1].style.aspectRatio = "1/0.78";
            cardnBanner[1].style.width = "130vh";
            posaBanner.style.paddingLeft = "0";

            cardnBanner[1].addEventListener("transitionend", () => {
                posaBanner.appendChild(cardnBanner[0]);
                posaBanner.lastElementChild.classList.remove("start");
                posaBanner.lastElementChild.style = "";
                posaBanner.firstElementChild.classList.replace("otw", "start");
            });
        }, 100);
    }, 100);
}, 5000);

// gallery
let num = document.querySelectorAll(".num-gallery");
let boardGallery = document.querySelectorAll(".card-gallery");

for (let i = 0; i < num.length; i++) {
    num[i].innerHTML = i + 1;
}

for (let i = 0; i < boardGallery.length; i++) {
    let timeoutMouseEnter;

    boardGallery[i].addEventListener("mouseenter", () => {
        timeoutMouseEnter = setTimeout(() => {
            boardGallery[i].querySelector(".board-gallery").style.opacity = "1";
        }, 300);
    });

    boardGallery[i].addEventListener("mouseleave", () => {
        clearTimeout(timeoutMouseEnter);

        boardGallery[i].querySelector(".board-gallery").style.opacity = "0";
    });
}

// services

let services = document.querySelector(".services");
let delay;

window.addEventListener("scroll", () => {
    if (window.scrollY > services.offsetTop - 300) {
        services.classList.add("onview");
        delay = setTimeout(() => {
            services.querySelector(".list-service").style.opacity = "1";
        }, 1000);
    } else {
        clearTimeout(delay);
        services.querySelector(".list-service").style.opacity = "0";
        services.classList.remove("onview");
    }
});

// portfolio

let motion = document.querySelector(".motion-port");
let portfolio = document.querySelector(".portfolio");
let motionG;

window.addEventListener("scroll", () => {
    if (window.scrollY > portfolio.offsetTop + portfolio.style.height - 100) {
        motionG = setTimeout(() => {
            motion.classList.add("onview");
            setTimeout(() => {
                motion.classList.remove("onview");
                setTimeout(() => {
                    motion.style.display = "none";

                    setTimeout(() => {
                        portfolio.querySelector(
                            ".board-portfolio"
                        ).style.opacity = "1";
                    }, 1000);
                }, 2000);
            }, 500);
        }, 1000);
    } else if (
        window.scrollY <
        portfolio.offsetTop - 500
    ) {
        clearTimeout(motionG);
        motion.style.display = "inherit";
        portfolio.querySelector(".board-portfolio").style.opacity = "0";
    }
});
